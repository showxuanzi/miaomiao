<template>
    <div id="main">
        <TopHead title="我的喵喵"/>
        <TabBar/>
    </div>
</template>
<script>
    import TopHead from '@/components/TopHead';
    import TabBar from '@/components/TabBar';
    export default {
        name: "Mine",
        components: {
            TopHead,
            TabBar
        }
    }
</script>