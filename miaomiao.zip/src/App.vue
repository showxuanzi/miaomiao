<template>
  <keep-alive>
    <router-view/>
  </keep-alive>
</template>